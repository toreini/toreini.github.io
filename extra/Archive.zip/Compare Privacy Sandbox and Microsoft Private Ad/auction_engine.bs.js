const ads = [
  { id: 1, topic: 'tech', bid: 1.5, creative: 'Ad: Get a new laptop' },
  { id: 2, topic: 'gaming', bid: 2.0, creative: 'Ad: Play the latest RPG' },
  { id: 3, topic: 'fitness', bid: 1.2, creative: 'Ad: Join a new gym' },
  { id: 4, topic: 'gardening', bid: 1.3, creative: 'Ad: Gardening Tools' },
  { id: 5, topic: 'cooking', bid: 1.1, creative: 'Ad: Kitchen Gadgets' }
];

function runAuction(topics) {
  const eligible = ads.filter(ad => topics.includes(ad.topic));
  eligible.sort((a, b) => b.bid - a.bid);
  return eligible.length ? eligible[0] : { creative: 'Fallback Ad' };
}

module.exports = { runAuction };
