const express = require('express');
const app = express();
const PORT = 3000;

const ads = {
  tech: '<h1>Ad: New GPU Launched!</h1>',
  fitness: '<h1>Ad: Gym Membership Discount!</h1>',
  gaming: '<h1>Ad: Top 10 Games of the Year!</h1>',
  cooking: '<h1>Ad: New Kitchen Tools Available!</h1>',
  gardening: '<h1>Ad: Spring Gardening Essentials!</h1>'
};

app.get('/ad/:topic', (req, res) => {
  const ad = ads[req.params.topic] || '<h1>Generic Ad</h1>';
  res.send(`<html><body>${ad}</body></html>`);
});

app.listen(PORT, () => console.log(`Ad server running at http://localhost:${PORT}`));
