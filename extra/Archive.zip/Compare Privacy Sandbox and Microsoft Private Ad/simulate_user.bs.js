const puppeteer = require('puppeteer');
const { runAuction } = require('./auction_engine');

const USER_PROFILES = [
  { name: 'UserA', topics: ['tech', 'gaming'] },
  { name: 'UserB', topics: ['fitness'] },
  { name: 'UserC', topics: ['cooking', 'gardening'] }
];

const htmlTemplate = (topics) => `
<html>
  <head><title>Topics API Test</title></head>
  <body>
    <script>
      document.write('<h2>Simulated interests: ${topics.join(', ')}</h2>');

      async function fetchTopics() {
        if ('browsingTopics' in document) {
          const topics = await document.browsingTopics();
          return topics.map(t => t.topic);
        } else {
          return ${JSON.stringify(topics)};
        }
      }

      window.fetchTopics = fetchTopics;
    </script>
  </body>
</html>
`;

async function simulateUser(user) {
  const browser = await puppeteer.launch({
    headless: false,
    args: [
      '--enable-features=PrivacySandboxAdsAPIsOverride,TopicsAPI',
      '--disable-features=PrivacySandboxSettings4'
    ]
  });

  const page = await browser.newPage();
  await page.setContent(htmlTemplate(user.topics));

  // Simulate wait and interaction
  await page.waitForTimeout(3000);

  // Extract topics from simulated API
  const topics = await page.evaluate(async () => await window.fetchTopics());
  const auctionResult = runAuction(topics);

  console.log(`
=== ${user.name} ===`);
  console.log('Topics:', topics);
  console.log('Winning Ad:', auctionResult);

  await browser.close();
}

(async () => {
  for (const user of USER_PROFILES) {
    await simulateUser(user);
  }
})();
