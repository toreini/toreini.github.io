const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
  const browser = await puppeteer.launch({
    headless: false,
    args: [
      '--proxy-server=http://localhost:8080',
      '--enable-blink-features=InterestGroupStorage,FencedFrames'
    ],
  });

  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36');

  await page.setRequestInterception(true);
  page.on('request', req => req.continue());

  page.on('response', async (res) => {
    const url = res.url();
    const ct = res.headers()['content-type'] || '';
    if (ct.includes('json') || url.includes('openrtb') || url.includes('bid')) {
      try {
        const body = await res.text();
        const parsed = require('./parser').parseOpenRTB(body);
        if (parsed) {
          console.log("🎯 OpenRTB Data:", parsed);
          fs.appendFileSync('logs/openrtb_log.jsonl', JSON.stringify({ url, data: parsed }) + '\n');
        }
      } catch (e) {}
    }
  });

  await page.goto('https://www.nytimes.com', { waitUntil: 'networkidle2' });
  await page.waitForTimeout(20000);
  await browser.close();
})();
