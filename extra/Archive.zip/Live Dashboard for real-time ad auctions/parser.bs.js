function parseOpenRTB(jsonString) {
  try {
    const data = JSON.parse(jsonString);
    if (data.seatbid) {
      return data.seatbid.flatMap(sb =>
        sb.bid.map(bid => ({
          bidder: sb.seat,
          price: bid.price,
          adid: bid.adid || null,
          crid: bid.crid || null,
          adomain: bid.adomain || [],
        }))
      );
    }
  } catch (err) {
    return null;
  }
  return null;
}

module.exports = { parseOpenRTB };
