# OpenRTB Inspector

A full working example that uses Puppeteer, mitmproxy, and a custom parser to observe and log OpenRTB ad auction traffic.

## Features

- Launches a headful browser using Puppeteer.
- Routes traffic through mitmproxy for full HTTPS inspection.
- Captures and parses OpenRTB bid requests and responses.
- Logs bidder info, prices, ad domains, creatives, and winners.

## Requirements

- Node.js (v18+)
- mitmproxy
- Python 3 (for optional enhancements)

## Setup

1. **Install mitmproxy** and trust its root certificate:

```bash
brew install mitmproxy
open /Applications/Utilities/Keychain\ Access.app
# Import and trust: ~/.mitmproxy/mitmproxy-ca-cert.pem
```

2. **Install Node.js dependencies**:

```bash
npm install
```

3. **Run mitmproxy**:

```bash
mitmweb --listen-port 8080
```

4. **Run Puppeteer**:

```bash
node index.js
```

5. **Inspect traffic** at `http://localhost:8081`.

