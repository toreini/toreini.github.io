
const express = require('express');
const app = express();
const port = 5001;

const userProfiles = {};

app.get('/bid', (req, res) => {
  const { uid, site } = req.query;
  if (!userProfiles[uid]) userProfiles[uid] = { visits: [] };
  userProfiles[uid].visits.push(site);

  const score = userProfiles[uid].visits.length;
  res.json({
    dsp: 'DSP1',
    price: score * 0.1,
    creative: `Buy shoes now (interest score: ${score})`
  });
});

app.listen(port, () => console.log(`DSP1 running on port ${port}`));
