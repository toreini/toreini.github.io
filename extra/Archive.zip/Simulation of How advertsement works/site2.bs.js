
const express = require('express');
const app = express();
const port = 3002;

app.get('/visit', (req, res) => {
  const uid = req.headers.cookie?.match(/uid=(\w+)/)?.[1] || 'anon';
  console.log(`User ${uid} visited site 2`);
  res.send(`
    <html>
      <body>
        <img src="http://localhost:4000/pixel?uid=${uid}&site=site2">
        <script src="http://localhost:4000/ad?uid=${uid}&site=site2"></script>
      </body>
    </html>
  `);
});

app.listen(port, () => console.log(`Site 2 running on port ${port}`));
