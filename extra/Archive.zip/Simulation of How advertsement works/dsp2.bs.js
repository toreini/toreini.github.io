
const express = require('express');
const app = express();
const port = 5002;

const userProfiles = {};

app.get('/bid', (req, res) => {
  const { uid, site } = req.query;
  if (!userProfiles[uid]) userProfiles[uid] = { interests: new Set() };
  userProfiles[uid].interests.add(site);

  const score = userProfiles[uid].interests.size;
  res.json({
    dsp: 'DSP2',
    price: score * 0.12,
    creative: `Limited offer on gadgets (${score} categories tracked)`
  });
});

app.listen(port, () => console.log(`DSP2 running on port ${port}`));
