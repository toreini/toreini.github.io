
const axios = require('axios');

const simulateUser = async (userId, sites) => {
  for (const site of sites) {
    console.log(`User ${userId} visiting ${site}`);
    await axios.get(`${site}/visit`, {
      headers: { 'Cookie': `uid=${userId}` }
    });
    await new Promise(r => setTimeout(r, 1000));
  }
};
simulateUser('user123', ['http://localhost:3001', 'http://localhost:3002']);
