
const express = require('express');
const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));
const app = express();
const port = 4000;

const dspUrls = ['http://localhost:5001/bid', 'http://localhost:5002/bid'];

app.get('/ad', async (req, res) => {
  const uid = req.query.uid;
  const site = req.query.site;

  const bids = await Promise.all(dspUrls.map(url =>
    fetch(`${url}?uid=${uid}&site=${site}`).then(r => r.json()).catch(e => ({ price: 0 }))
  ));
  const winner = bids.reduce((max, b) => b.price > max.price ? b : max, { price: 0 });

  res.send(`<div style="border:1px solid black">Ad from ${winner.dsp}: ${winner.creative}</div>`);
});

app.get('/pixel', (req, res) => {
  const { uid, site } = req.query;
  console.log(`Tracking pixel hit: user=${uid}, site=${site}`);
  res.sendStatus(200);
});

app.listen(port, () => console.log(`Ad Exchange running on port ${port}`));
