
const express = require('express');
const app = express();
const port = 3001;

app.get('/visit', (req, res) => {
  const uid = req.headers.cookie?.match(/uid=(\w+)/)?.[1] || 'anon';
  console.log(`User ${uid} visited site 1`);
  res.send(`
    <html>
      <body>
        <img src="http://localhost:4000/pixel?uid=${uid}&site=site1">
        <script src="http://localhost:4000/ad?uid=${uid}&site=site1"></script>
      </body>
    </html>
  `);
});

app.listen(port, () => console.log(`Site 1 running on port ${port}`));
